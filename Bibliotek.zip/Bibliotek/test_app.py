def test_book_get_all(server):
    endpoint = server.get("/Books")
    endpoint_data = endpoint.json

    for data in endpoint_data:
        assert "Title" in data
        assert "author" in data
        assert "book id" in data
        assert "genre" in data
        assert "summary" in data

def test_book_by_id(server):
    endpoint = server.get("/Books/5")
    endpoint_data = endpoint.json

    assert any(data.get("book id") == 5 for data in endpoint_data)

