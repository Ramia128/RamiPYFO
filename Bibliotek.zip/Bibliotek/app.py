from flask import Flask, request, jsonify
import sqlite3, requests, os

app = Flask(__name__)
f_home = os.path.expanduser("~")
db_path = os.path.join(f_home, "Downloads/bibliotek", "bibliotek.db")

def db_connect():
    return sqlite3.connect(db_path)

def db_query(query, params=None):
    connection = db_connect()
    cursor = connection.cursor()

    if params and isinstance(params, list) and isinstance(params[0], tuple):
        cursor.executemany(query, params)
    elif params:
        cursor.execute(query, params)
    else:
        cursor.execute(query)
    data = cursor.fetchall()
    connection.commit()
    connection.close()
    return data

@app.route("/Books", methods=["GET"])
def books_show_all():
    genre = request.args.get("genre")
    title = request.args.get("title")
    author = request.args.get("author")

    if genre:
        query = "SELECT * FROM Books WHERE genre LIKE ?"
        params = (f"%{genre}%",)
        rows = db_query(query, params)
    elif title:
        query = "SELECT * FROM Books WHERE title LIKE ?"
        params = (f"%{title}%",)
        rows = db_query(query, params)
    elif author:
        query = "SELECT * FROM Books WHERE author LIKE ?"
        params = (f"%{author}%",)
        rows = db_query(query, params)    
    else:
        query = "SELECT * FROM Books"
        rows = db_query(query)
    
    data_list = []
    for row in rows:
        data_info = {
            "Title": row[2],
            "genre": row[3],
            "author": row[1],
            "book id": row[0],
            "summary": row[4]
        }
        data_list.append(data_info)
    
    return jsonify(data_list)

@app.route("/Books/<book_id>", methods=["GET"])
def books_by_id(book_id):
    query = "SELECT * FROM Books WHERE id LIKE ?"
    params = (book_id,)
    rows = db_query(query, params)

    data_list = []
    for row in rows:
        data_info = {
            "Title": row[2],
            "genre": row[3],
            "author": row[1],
            "book id": row[0],
            "summary": row[4]
        }
        data_list.append(data_info)


    return jsonify(data_list)

@app.route("/Books/<book_id>", methods=["POST"])
def book_add_review(book_id):
    reviewtext = request.get_json()
    if not isinstance(reviewtext, list):
        reviewtext = [reviewtext]
    query = f"INSERT INTO Reviews (book_id, user, rating, review) VALUES(?, ?, ?, ?)"
    params = []
    for review_add in reviewtext:
        user = review_add.get("user")
        rating = int(review_add.get("rating"))
        review = review_add.get("review")
        if not (1 <= rating <= 5):
            return jsonify("You must rate the book between 1-5"), 201
        params.append((book_id, user, rating, review))
    db_query(query, params)
    return jsonify(f"Review added to bookid: {book_id}")


@app.route("/Books/<book_id>", methods=["DELETE"])
def book_delete(book_id):

    book_q = "DELETE FROM Books where id LIKE ?"
    book_p = (book_id,)
    db_query(book_q, book_p)

    review_q = "DELETE FROM Reviews WHERE book_id LIKE ?"
    review_p = (book_id,)
    db_query(review_q, review_p)

    return jsonify("Book deleted successfully!")

@app.route("/Books/<book_id>", methods=["PUT"])
def book_update(book_id):
    update = request.get_json()
    set_info = ", ".join(f"{info} = ?" for info in update.keys())
    query = f"UPDATE Books SET {set_info} WHERE id LIKE ?"
    params = list(update.values()) + [book_id]
    db_query(query, params)
    return jsonify(f"Book {book_id} updated!")

@app.route("/Books", methods=["POST"])
def book_add():
    add_book = request.get_json()

    if not isinstance(add_book, list):
        add_book = [add_book]
    
    query = "INSERT INTO Books (title, genre, author, summary) VALUES (?, ?, ?, ?)"

    params = []
    for book in add_book:
        title = book.get("title")
        genre = book.get("genre")
        author = book.get("author")
        summary = book.get("summary")
        params.append((title, genre, author, summary))

    db_query(query, params)
    if len(add_book) == 1:
        return "Added new book!"
    else:
        return "Added new books!"

@app.route("/Books/top", methods=["GET"])
def book_top():
    query = "SELECT Books.title, round(avg(rating), 1) as top_rating FROM Reviews JOIN Books ON Books.id = Reviews.book_id GROUP BY Books.id ORDER BY top_rating DESC LIMIT 5"
    rows = db_query(query)
    data_list = []
    for row in rows:
        data_info = {
            "Book": row[0],
            "rating": row[1],
        }
        data_list.append(data_info)
    return jsonify(data_list)


@app.route("/Reviews", methods=["GET"])
def reviews_show_all():
    query = "SELECT Books.title, Reviews.user, Reviews.rating, Reviews.review From Reviews JOIN Books ON Books.id = Reviews.book_id"
    rows = db_query(query)
    data_list = []
    for row in rows:
        data_info = {
            "Title": row[0],
            "User": row[1],
            "rating": row[2],
            "review": row[3],
        }
        data_list.append(data_info)
     
    return jsonify(data_list)
    
@app.route("/Reviews/<book_id>", methods=["GET"])
def review_by_id(book_id):
    query = "SELECT Books.title, Reviews.user, Reviews.rating, Reviews.review FROM Reviews JOIN Books ON Books.id = Reviews.Book_id WHERE Books.id LIKE ?"
    params = (book_id,)
    rows = db_query(query, params)
    data_list = []
    for row in rows:
        data_info = {
            "Title": row[0],
            "User": row[1],
            "rating": row[2],
            "review": row[3],
        }
        data_list.append(data_info)
    return jsonify(data_list)

@app.route("/Author/<author_name>", methods=["GET"])
def author_info(author_name):
    author_url = requests.get(f"https://en.wikipedia.org/api/rest_v1/page/summary/{author_name}")
    author_data = author_url.json()
    author_summary = author_data.get("extract")
    author_dict = {
        author_name: author_summary
    }
    

    return jsonify(author_dict)



if __name__ == "__main__":
    app.run(debug=True)
