import pytest
from app import app

@pytest.fixture
def server():
    with app.test_client() as server:
        yield server
